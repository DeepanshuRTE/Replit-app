import { useChat } from "@/hooks/use-chat";
import { ChatHeader } from "@/components/chat-header";
import { MessageList } from "@/components/message-list";
import { MessageInput } from "@/components/message-input";
import { TypingIndicator } from "@/components/typing-indicator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

export default function Chatbot() {
  const {
    messages,
    isLoading,
    error,
    isTyping,
    sendMessage,
    clearChat,
    retryLastMessage,
  } = useChat();

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto bg-white shadow-xl">
      <ChatHeader onClearChat={clearChat} />
      
      <main className="flex-1 overflow-y-auto p-4 space-y-4">
        <MessageList messages={messages} />
        {isTyping && <TypingIndicator />}
      </main>

      {error && (
        <div className="px-4 pb-2">
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="h-4 w-4 text-red-500" />
            <AlertDescription className="text-red-700 flex items-center justify-between">
              <span>{error}</span>
              <Button
                variant="link"
                size="sm"
                onClick={retryLastMessage}
                className="text-red-600 hover:text-red-800 p-0 h-auto"
              >
                Retry
              </Button>
            </AlertDescription>
          </Alert>
        </div>
      )}

      <MessageInput onSendMessage={sendMessage} disabled={isLoading} />
    </div>
  );
}
