import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Upload, FileText, Trash2 } from "lucide-react";

interface Document {
  id: string;
  title: string;
  content: string;
  type: 'pdf' | 'text';
  createdAt: Date;
}

export default function Documentation() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [newDocTitle, setNewDocTitle] = useState("");
  const [newDocContent, setNewDocContent] = useState("");

  const handleAddDocument = () => {
    if (!newDocTitle.trim() || !newDocContent.trim()) return;

    const newDoc: Document = {
      id: `doc_${Date.now()}`,
      title: newDocTitle,
      content: newDocContent,
      type: 'text',
      createdAt: new Date(),
    };

    setDocuments(prev => [newDoc, ...prev]);
    setNewDocTitle("");
    setNewDocContent("");
  };

  const handleDeleteDocument = (id: string) => {
    setDocuments(prev => prev.filter(doc => doc.id !== id));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const newDoc: Document = {
        id: `doc_${Date.now()}`,
        title: file.name,
        content: content,
        type: file.type === 'application/pdf' ? 'pdf' : 'text',
        createdAt: new Date(),
      };
      setDocuments(prev => [newDoc, ...prev]);
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Documentation</h1>
        <p className="text-gray-600">Store and manage your project documentation</p>
      </div>

      {/* Add New Document */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Add New Document</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input
            placeholder="Document title"
            value={newDocTitle}
            onChange={(e) => setNewDocTitle(e.target.value)}
          />
          <Textarea
            placeholder="Document content"
            value={newDocContent}
            onChange={(e) => setNewDocContent(e.target.value)}
            rows={6}
          />
          <div className="flex gap-2">
            <Button onClick={handleAddDocument}>
              <FileText className="w-4 h-4 mr-2" />
              Add Document
            </Button>
            <Button variant="outline" onClick={() => document.getElementById('file-upload')?.click()}>
              <Upload className="w-4 h-4 mr-2" />
              Upload File
            </Button>
            <input
              id="file-upload"
              type="file"
              accept=".txt,.md,.pdf"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
        </CardContent>
      </Card>

      {/* Documents List */}
      <div className="space-y-4">
        {documents.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <p className="text-gray-500">No documents yet. Add your first document above.</p>
            </CardContent>
          </Card>
        ) : (
          documents.map((doc) => (
            <Card key={doc.id}>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">{doc.title}</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDeleteDocument(doc.id)}
                  className="text-red-500 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <pre className="whitespace-pre-wrap text-sm">{doc.content}</pre>
                </div>
                <div className="mt-2 text-xs text-gray-500">
                  Created: {doc.createdAt.toLocaleDateString()}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}