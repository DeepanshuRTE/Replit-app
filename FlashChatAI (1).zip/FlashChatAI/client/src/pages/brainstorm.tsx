import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageList } from "@/components/message-list";
import { MessageInput } from "@/components/message-input";
import { TypingIndicator } from "@/components/typing-indicator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Brain, Download, ArrowLeft, AlertTriangle } from "lucide-react";
import { ChatMessage } from "@shared/schema";
import { Link } from "wouter";

const BRAINSTORM_API_ENDPOINT =
  "https://engine.flashbuild.ai/execute-flow/flow_6b1ff423-a971-489d-8093-a5326a7a930e";

export default function Brainstorm() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isComplete, setIsComplete] = useState(false);
  const [documentTitle, setDocumentTitle] = useState("");
  const [finalDocumentation, setFinalDocumentation] = useState("");

  const sendMessage = async (messageText: string) => {
    const userMessage: ChatMessage = {
      message: messageText,
      isUser: true,
      timestamp: new Date().toISOString(),
    };

    // Add user message immediately
    setMessages((prev) => [...prev, userMessage]);
    setError(null);
    setIsLoading(true);
    setIsTyping(true);

    // Set document title from first message if not set
    if (!documentTitle && messages.length === 0) {
      setDocumentTitle(messageText);
    }

    try {
      // Format previous chat history
      const previousChatHistory = messages
        .map((msg) => `${msg.isUser ? "User" : "Bot"}: ${msg.message}`)
        .join("\n");

      // Send the user query with previous chat history
      const requestBody = {
        user_queries: messageText,
        "preivous chat": previousChatHistory,
      };

      console.log("Sending brainstorm request to:", BRAINSTORM_API_ENDPOINT);
      console.log("Request body:", requestBody);

      const response = await fetch(BRAINSTORM_API_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const responseText = await response.json();
      console.log("Brainstorm response:", responseText);

      // Parse the response (handle multiple levels of JSON encoding)
      let responseData;
      try {
        // First parse - get the outer response
        const firstParse = JSON.parse(responseText);
        console.log("First parse:", firstParse);

        // The result field contains the actual response data
        if (firstParse && firstParse.result) {
          responseData = firstParse.result;
          console.log("Extracted result:", responseData);
          console.log("Response field exists?", !!responseData.response);
          console.log("Response value:", responseData.response);
        } else {
          responseData = firstParse;
        }
      } catch (error) {
        console.error("JSON parsing error:", error);
        responseData = { response: "Error parsing response" };
      }

      console.log("Final parsed brainstorm data:", responseData);

      let botMessageText =
        "I'm sorry, I didn't understand that. Could you please rephrase?";

      // Extract the response text from the result object
      if (responseData && responseData.response) {
        botMessageText = responseData.response;
        console.log("Successfully extracted response text");
      } else {
        console.log("Failed to find response field in:", responseData);
      }

      console.log("Final bot message text:", botMessageText);

      // Check if brainstorming is complete
      if (
        responseData &&
        (responseData.brain_stroming === "true" ||
          (responseData.result &&
            responseData.result.brain_stroming === "true"))
      ) {
        setIsComplete(true);
        setFinalDocumentation(botMessageText);
      }

      // Clean up Markdown formatting
      if (typeof botMessageText === "string") {
        botMessageText = botMessageText
          .replace(/\*\*(.*?)\*\*/g, "$1") // Remove **bold**
          .replace(/\*(.*?)\*/g, "$1") // Remove *italic*
          .replace(/`(.*?)`/g, "$1") // Remove `code`
          .replace(/#{1,6}\s*/g, "") // Remove # headers
          .replace(/^\s*[-*+]\s*/gm, "• "); // Convert - * + to bullet points
      }

      const botMessage: ChatMessage = {
        message: botMessageText,
        isUser: false,
        timestamp: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (err) {
      console.error("Brainstorm API Error:", err);

      let errorMessage =
        "Sorry, I'm having trouble connecting to the brainstorming service. ";
      if (err instanceof Error) {
        if (err.message.includes("Failed to fetch")) {
          errorMessage += "Please check your internet connection.";
        } else if (err.message.includes("API Error")) {
          errorMessage += "The service is temporarily unavailable.";
        } else {
          errorMessage += "Please try again.";
        }
      } else {
        errorMessage += "Please try again.";
      }

      setError(errorMessage);
    } finally {
      setIsLoading(false);
      setIsTyping(false);
    }
  };

  const downloadPDF = () => {
    // Create PDF content
    const pdfContent = `Feature Documentation: ${documentTitle || "Brainstorm Session"}

${finalDocumentation}

Generated on: ${new Date().toLocaleDateString()}
`;

    // Create blob and download
    const blob = new Blob([pdfContent], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${documentTitle || "brainstorm-session"}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const clearChat = () => {
    if (
      window.confirm(
        "Are you sure you want to start a new brainstorming session?",
      )
    ) {
      setMessages([]);
      setError(null);
      setIsComplete(false);
      setDocumentTitle("");
      setFinalDocumentation("");
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto bg-white shadow-xl">
      {/* Header */}
      <header className="bg-white border-b border-[hsl(var(--header-border))] px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Link href="/">
            <Button variant="ghost" size="sm" className="p-2">
              <ArrowLeft size={16} />
            </Button>
          </Link>
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center">
            <Brain className="text-white" size={20} />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-slate-900">
              Feature Brainstorm
            </h1>
            <p className="text-sm text-slate-500">
              {isComplete ? "Session Complete" : "Active Session"}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {isComplete && (
            <Button
              onClick={downloadPDF}
              size="sm"
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Download size={16} className="mr-2" />
              Download PDF
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={clearChat}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            New Session
          </Button>
        </div>
      </header>

      {/* Welcome Card */}
      {messages.length === 0 && (
        <div className="p-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="text-purple-600" size={20} />
                <span>Start Brainstorming</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 mb-4">
                Describe the feature you'd like to brainstorm and I'll help you
                develop it into a comprehensive specification with user stories,
                edge cases, and implementation details.
              </p>
              <p className="text-sm text-slate-500">
                Example: "I want to build a calculator feature for my app"
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Messages */}
      <main className="flex-1 overflow-y-auto p-4 space-y-4">
        <MessageList messages={messages} />
        {isTyping && <TypingIndicator />}

        {isComplete && (
          <Card className="bg-green-50 border-green-200">
            <CardContent className="pt-4">
              <div className="flex items-center space-x-2 text-green-700">
                <Brain size={16} />
                <span className="font-medium">Brainstorming Complete!</span>
              </div>
              <p className="text-green-600 text-sm mt-1">
                Your feature documentation is ready. You can download it as a
                PDF above.
              </p>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Error */}
      {error && (
        <div className="px-4 pb-2">
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="h-4 w-4 text-red-500" />
            <AlertDescription className="text-red-700">
              {error}
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* Input */}
      <MessageInput
        onSendMessage={sendMessage}
        disabled={isLoading || isComplete}
      />
    </div>
  );
}
