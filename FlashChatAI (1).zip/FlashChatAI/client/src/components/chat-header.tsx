import { Button } from "@/components/ui/button";
import { Bot, Trash2, Brain } from "lucide-react";
import { Link } from "wouter";

interface ChatHeaderProps {
  onClearChat: () => void;
}

export function ChatHeader({ onClearChat }: ChatHeaderProps) {
  return (
    <header className="bg-white border-b border-[hsl(var(--header-border))] px-4 py-4 flex items-center justify-between">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
          <Bot className="text-white" size={20} />
        </div>
        <div>
          <h1 className="text-lg font-semibold text-slate-900">AI Assistant</h1>
          <p className="text-sm text-slate-500">Online</p>
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        <Link href="/brainstorm">
          <Button
            variant="default"
            size="sm"
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            <Brain size={16} className="mr-2" />
            🧠 Brainstorm
          </Button>
        </Link>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearChat}
          className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100"
        >
          <Trash2 size={16} />
        </Button>
      </div>
    </header>
  );
}
