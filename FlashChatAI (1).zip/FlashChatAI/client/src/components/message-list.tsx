import { useEffect, useRef } from "react";
import { ChatMessage } from "@shared/schema";
import { cn } from "@/lib/utils";

interface MessageListProps {
  messages: ChatMessage[];
}

interface MessageBubbleProps {
  message: ChatMessage;
}

function MessageBubble({ message }: MessageBubbleProps) {
  const timestamp = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div className={cn("flex", message.isUser ? "justify-end" : "justify-start")}>
      <div className="max-w-xs lg:max-w-md">
        <div
          className={cn(
            "px-4 py-3 rounded-2xl",
            message.isUser
              ? "bg-[hsl(var(--user-message))] text-[hsl(var(--user-message-foreground))] rounded-tr-md"
              : "bg-[hsl(var(--bot-message))] text-[hsl(var(--bot-message-foreground))] rounded-tl-md"
          )}
        >
          <p className="text-sm whitespace-pre-wrap">{message.message}</p>
        </div>
        <p className={cn(
          "text-xs text-slate-400 mt-1",
          message.isUser ? "text-right mr-2" : "ml-2"
        )}>
          {timestamp}
        </p>
      </div>
    </div>
  );
}

function WelcomeMessage() {
  return (
    <div className="flex justify-start">
      <div className="max-w-xs lg:max-w-md">
        <div className="bg-[hsl(var(--bot-message))] text-[hsl(var(--bot-message-foreground))] rounded-2xl rounded-tl-md px-4 py-3">
          <p className="text-sm">👋 Hello! I'm your AI assistant. How can I help you today?</p>
        </div>
        <p className="text-xs text-slate-400 mt-1 ml-2">Just now</p>
      </div>
    </div>
  );
}

export function MessageList({ messages }: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <div className="space-y-4">
      {messages.length === 0 && <WelcomeMessage />}
      {messages.map((message, index) => (
        <MessageBubble key={index} message={message} />
      ))}
      <div ref={messagesEndRef} />
    </div>
  );
}
