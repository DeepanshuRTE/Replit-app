export function TypingIndicator() {
  return (
    <div className="flex justify-start">
      <div className="max-w-xs lg:max-w-md">
        <div className="bg-[hsl(var(--bot-message))] rounded-2xl rounded-tl-md px-4 py-3 flex items-center space-x-1">
          <div className="flex space-x-1">
            <div 
              className="w-2 h-2 bg-[hsl(var(--typing-dots))] rounded-full animate-bounce-dots"
              style={{ animationDelay: "0ms" }}
            />
            <div 
              className="w-2 h-2 bg-[hsl(var(--typing-dots))] rounded-full animate-bounce-dots"
              style={{ animationDelay: "160ms" }}
            />
            <div 
              className="w-2 h-2 bg-[hsl(var(--typing-dots))] rounded-full animate-bounce-dots"
              style={{ animationDelay: "320ms" }}
            />
          </div>
          <span className="text-xs text-slate-500 ml-2">AI is typing...</span>
        </div>
      </div>
    </div>
  );
}
