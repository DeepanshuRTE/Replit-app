import { Link, useLocation } from "wouter";
import { MessageCircle, Lightbulb, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();

  const navigation = [
    {
      name: "Chat with API",
      href: "/",
      icon: MessageCircle,
      current: location === "/",
    },
    {
      name: "Brainstorm",
      href: "/brainstorm",
      icon: Lightbulb,
      current: location === "/brainstorm",
    },
    {
      name: "Documentation",
      href: "/documentation",
      icon: FileText,
      current: location === "/documentation",
    },
  ];

  return (
    <div className={cn("flex h-full w-64 flex-col bg-gray-50 dark:bg-gray-900", className)}>
      <div className="flex flex-1 flex-col overflow-y-auto pt-5 pb-4">
        <div className="flex items-center flex-shrink-0 px-4">
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">
            Beek Health
          </h1>
        </div>
        <nav className="mt-8 flex-1 space-y-1 px-2">
          {navigation.map((item) => (
            <Link key={item.name} href={item.href}>
              <a
                className={cn(
                  item.current
                    ? "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white"
                    : "text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white",
                  "group flex items-center px-2 py-2 text-sm font-medium rounded-md"
                )}
              >
                <item.icon
                  className={cn(
                    item.current
                      ? "text-gray-500 dark:text-gray-300"
                      : "text-gray-400 group-hover:text-gray-500 dark:group-hover:text-gray-300",
                    "mr-3 flex-shrink-0 h-6 w-6"
                  )}
                  aria-hidden="true"
                />
                {item.name}
              </a>
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
}