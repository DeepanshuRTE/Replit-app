import { useState, useCallback } from "react";
import { ChatMessage, ChatHistory } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

const API_ENDPOINT = "https://engine.flashbuild.ai/execute-flow/flow_518cc450-8472-4da3-b720-38ec38bec1b8";

export function useChat() {
  const [messages, setMessages] = useState<ChatHistory>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUserMessage, setLastUserMessage] = useState<string | null>(null);

  const sendMessage = useCallback(async (messageText: string) => {
    const userMessage: ChatMessage = {
      message: messageText,
      isUser: true,
      timestamp: new Date().toISOString(),
    };

    // Add user message immediately
    setMessages(prev => [...prev, userMessage]);
    setLastUserMessage(messageText);
    setError(null);
    setIsLoading(true);
    setIsTyping(true);

    try {
      // Format previous chat history as a string
      const previousChatHistory = messages.map(msg => 
        `${msg.isUser ? 'User' : 'Bot'}: ${msg.message}`
      ).join('\n');
      
      // Send the user query with previous chat history
      const requestBody = {
        user_query: messageText,
        previous_chat: previousChatHistory
      };
      
      console.log('Sending request to API:', API_ENDPOINT, requestBody);
      
      const response = await fetch(API_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
      });
      
      console.log('Response status:', response.status);
      
      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }
      
      const responseText = await response.text();
      console.log('Response text:', responseText);
      
      // Parse the response as JSON (handle double-encoded JSON)
      let responseData;
      try {
        // First parse to get the string
        const firstParse = JSON.parse(responseText);
        // Then parse again if it's still a string
        responseData = typeof firstParse === 'string' ? JSON.parse(firstParse) : firstParse;
      } catch {
        responseData = JSON.parse(responseText);
      }
      
      console.log('Parsed response data:', responseData);
      
      // Extract only the result field from the API response
      let botMessageText = "I'm sorry, I didn't understand that. Could you please rephrase?";
      
      if (responseData && responseData.result) {
        // Check if result is an object with response field, or direct text
        if (typeof responseData.result === 'object' && responseData.result.response) {
          // Handle nested response objects
          if (typeof responseData.result.response === 'string') {
            botMessageText = responseData.result.response;
          } else if (typeof responseData.result.response === 'object') {
            // Convert complex object to readable text
            botMessageText = JSON.stringify(responseData.result.response, null, 2);
          }
        } else if (typeof responseData.result === 'string') {
          botMessageText = responseData.result;
        } else if (typeof responseData.result === 'object') {
          // Convert any object to readable text
          botMessageText = JSON.stringify(responseData.result, null, 2);
        }
        console.log('Extracted result:', botMessageText);
      } else {
        console.log('No result field found in response');
      }
      
      // Clean up Markdown formatting
      if (typeof botMessageText === 'string') {
        botMessageText = botMessageText
          .replace(/\*\*(.*?)\*\*/g, '$1') // Remove **bold**
          .replace(/\*(.*?)\*/g, '$1')     // Remove *italic*
          .replace(/`(.*?)`/g, '$1')       // Remove `code`
          .replace(/#{1,6}\s*/g, '')       // Remove # headers
          .replace(/^\s*[-*+]\s*/gm, '• '); // Convert - * + to bullet points
      }

      const botMessage: ChatMessage = {
        message: botMessageText,
        isUser: false,
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (err) {
      console.error("API Error:", err);
      
      let errorMessage = "Sorry, I'm having trouble connecting. ";
      if (err instanceof Error) {
        if (err.message.includes("Failed to fetch")) {
          errorMessage += "Please check your internet connection.";
        } else if (err.message.includes("API Error")) {
          errorMessage += "The service is temporarily unavailable.";
        } else {
          errorMessage += "Please try again.";
        }
      } else {
        errorMessage += "Please try again.";
      }
      
      setError(errorMessage);
    } finally {
      setIsLoading(false);
      setIsTyping(false);
    }
  }, [messages]);

  const retryLastMessage = useCallback(() => {
    if (lastUserMessage) {
      // Remove the last user message and retry
      setMessages(prev => prev.slice(0, -1));
      sendMessage(lastUserMessage);
    }
  }, [lastUserMessage, sendMessage]);

  const clearChat = useCallback(() => {
    if (window.confirm("Are you sure you want to clear the chat history?")) {
      setMessages([]);
      setError(null);
      setLastUserMessage(null);
    }
  }, []);

  return {
    messages,
    isLoading,
    isTyping,
    error,
    sendMessage,
    clearChat,
    retryLastMessage,
  };
}
