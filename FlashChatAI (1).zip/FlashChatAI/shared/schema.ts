import { z } from "zod";

export const chatMessageSchema = z.object({
  message: z.string().min(1),
  isUser: z.boolean(),
  timestamp: z.string(),
});

export type ChatMessage = z.infer<typeof chatMessageSchema>;

export const chatHistorySchema = z.array(chatMessageSchema);
export type ChatHistory = z.infer<typeof chatHistorySchema>;

export const documentSchema = z.object({
  id: z.string(),
  title: z.string(),
  content: z.string(),
  type: z.enum(['pdf', 'text']),
  createdAt: z.date(),
});

export type Document = z.infer<typeof documentSchema>;

export const insertDocumentSchema = documentSchema.omit({ id: true, createdAt: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
